"""Outline
takes a folder with solutions from a docking run and creates a subdirectory
for that compound. 
Solutions from docking runs are different conformers of the same compound.
Some conformers are more like each other than others and share a 3-dimensional
similarity score calculated by RMSD using the coordinates of their 
respective atom pairs. 

A user defined threshold for RMSD is given and this score is used to group 
confomers that lie within this threshold. 

The groups and their members are stated in the RMSD_report.txt file created
along with a bar chart with the conformer numbers and their respective
populations.


The RMSD_report also states the different rotations of the conformers and 
the number of members for each rotation. 

"""
import os 
from os import system 
from subprocess import * 
from matplotlib import pyplot as plt 

#dropped file as input
#finds forward slashes
#takes path and stores it in "Path"
#finds all files in .mol2 format and stores them in Ligands_pre list
#RMSD library used later requires input in the format "parent_folder/filename"
#compounds are placed in this format in Ligands list
Ligands_pre = [] 
Ligands = [] 
characters = [] 
forward_slashes = []
dropped_file = str(input('Drag a file to establish folder path' ))
for char in dropped_file: 
    characters.append(char)
for i in range(0, len(characters)):  
    if characters[i] == '/': 
        forward_slashes.append(i)
Path = str(dropped_file[:int(forward_slashes[-1])])
for root, dirs, files in os.walk(Path):
    for file in files: 
        if file.endswith(".mol2"): 
            Ligands_pre.append(os.path.join(root, file))  

for variable in Ligands_pre: 
    Ligands.append(variable[int(forward_slashes[-1]) + 1:]) 

#takes names of compounds as input
#if name is not "done"
#makes a subdirectory for name
subdirects = [] 
compound_names = str((raw_input)) 
while compound_names != 'done': 
    compound_names = str((raw_input('Type name of Ligand or type \'done\'' )))
    if compound_names != 'done':
        subdirects.append(compound_names)
for subdirect in subdirects:
    try: 
        os.makedirs(Path + '/' + subdirect) 
    except: 
        pass 
################################################################################         
""" Considers the coordinates of two different lines, if the coordiates are within threshold values, True is returned. 
    atoms must be of same type but atom number must be different. Used as part of the effort to recognise 'flipped' rings between compounds. """ 
    
def same_mol_check_2(q, r): 
    x = abs(float(q[19:25]))
    y = abs(float(q[28:34]))
    z = abs(float(q[37:43]))
    
    l = abs(float(r[19:25]))
    m = abs(float(r[28:34]))
    n = abs(float(r[37:43])) 
    
    dis = 0.50
    dis2 = 0.70
    dis3 = 0.90
    dis4 = 1.00 
    dis5 = 1.10 
    dis6 = 1.40 
    dis7 = 1.60 
    if (x - dis) <= l <= (x + dis) and (y - dis) <= m <= (y + dis) and (z - dis) \
    <= n <= (z + dis) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True
    elif (x - dis) <= l <= (x + dis) and (y - dis) <= m <= (y + dis2) and (z - dis) \
    <= n <= (z + dis) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True
    elif (x - dis2) <= l <= (x + dis2) and (y - dis2) <= m <= (y + dis2) and (z - dis2) \
    <= n <= (z + dis2) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True
    elif (x - dis5) <= l <= (x + dis5) and (y - dis) <= m <= (y + dis) and (z - dis) \
    <= n <= (z + dis) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True
    elif (x - dis) <= l <= (x + dis) and (y - dis5) <= m <= (y + dis5) and (z - dis) \
    <= n <= (z + dis) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True
    elif (x - dis) <= l <= (x + dis) and (y - dis) <= m <= (y + dis) and (z - dis5) \
    <= n <= (z + dis5) and str(i[8]) == str(o[8]) and str(i[5:7]) != str(o[5:7]):
        return True


########################################################################################################################
""" In the effort to recognise flipped rings, the bond section of a compound is searched for 6 consecutive lines with 'ar' bond type.
    These atoms and the atoms they are attached to are added to 'atoms to check' where their symmetry is evaluated. If they are found 
    to be symmetrical, they are added to a list of atoms that are allowed to 'flip'. Later flipped atoms are searched for, if found and are members 
    of the allowed-to-flip group, they are flipped back before RMSD calculations take place. """
    
flipped_1 = {}
for x in subdirects:
    flipped_1[x] = [] 

for y in flipped_1: 
    print y
    for x in Ligands:
      if str(y) in str(x):
        flipped_1[y].append(x)
        

for y in flipped_1:
  try:
    if str(y) == 'done':
      pass
    else: 
      comparison = flipped_1[y][1]
    for x in flipped_1[y]:
      dict_ring_members = {}
      dict_ring_members[x] = []
      with open(x, 'r+') as f, open(comparison, 'r') as g:
        f_contents = f.readlines() 
        g_contents = g.readlines()
        for i in range(0, len(f_contents)): 
          if f_contents[i][9:13] == 'BOND': 
            offset1 = i 
        for i in range(0, len(f_contents)): 
          if f_contents[i][9:13] == 'ATOM': 
            offset2 = i + 1 
        for i in range(offset2, offset1): 
          if f_contents[i][8] == 'H' and f_contents[i + 1][8] == 'H' \
          and f_contents[i + 2][8] == 'H' and f_contents[i - 1][8] != 'H': 
            offsetH = i  
        lines_to_check = []
        
        def atom_check(q):
          for i in range(offset2, offset1): 
            if f_contents[i][5:7] == q and f_contents[i][8] == 'H': 
              return True
            elif f_contents[i][5:7] == q and f_contents[i][8] != 'H': 
              return False 

        #find benzene carbons
        for i in range(offset1, len(f_contents)):                                                  
            if str(f_contents[i][16:18]) == 'ar' and str(f_contents[i - 1][16:18]) != 'ar' \
            and str(f_contents[i + 5][16:18]) == 'ar' and str(f_contents[i + 6][16:18]) != 'ar' \
            and str(f_contents[i + 1][16:18]) == 'ar' and str(f_contents[i + 2][16:18]) == 'ar' \
            and str(f_contents[i + 3][16:18]) == 'ar' and str(f_contents[i + 4][16:18]) == 'ar':
                lines_to_check.append(str(f_contents[i][13:15]))
                lines_to_check.append(str(f_contents[i + 1][13:15]))
                lines_to_check.append(str(f_contents[i + 3][13:15]))
                lines_to_check.append(str(f_contents[i + 5][13:15]))
                
            
        for i in range(offset1, len(f_contents)): 
          for z in lines_to_check: 
            if str(f_contents[i][8:10]) == str(z) and str(f_contents[i][16:18]) != 'ar' \
            and atom_check(str(f_contents[i][13:15])) == True:
              dict_ring_members[x].append(z) 
              dict_ring_members[x].append(str(f_contents[i][13:15]))
            elif str(f_contents[i][8:10]) == z and str(f_contents[i][16:18]) != 'ar' \
            and atom_check(str(f_contents[i][13:15])) == False: 
              pass 
                 
        for i in f_contents[offset2:offset1]: 
          for o in g_contents[offset2:offset1]:
            try: 
              if x == comparison: 
                pass
              elif same_mol_check_2(i, o) == True and \
              same_mol_check_2(g_contents[int(f_contents.index(i))], f_contents[int(g_contents.index(o))]) == True \
              and str(i[5:7]) in dict_ring_members[x] and str(o[5:7]) in dict_ring_members[x] and f_contents.index(i) < g_contents.index(o):
                newline_1 = str(f_contents[f_contents.index(i)][0:11]) + str(f_contents[g_contents.index(o)][11:])
                newline_2 = str(f_contents[g_contents.index(o)][0:11]) + str(f_contents[f_contents.index(i)][11:])
                
                f_contents[f_contents.index(i)] = newline_1
                f_contents[g_contents.index(o)] = newline_2
                
              elif same_mol_check_2(i, o) == True and \
              same_mol_check_2(g_contents[int(f_contents.index(i))], f_contents[int(g_contents.index(o))]) == True \
              and str(i[46:51]) == "O.co2" and str(o[46:51]) == "O.co2":
                newline_1 = str(f_contents[f_contents.index(i)][0:11]) + str(f_contents[g_contents.index(o)][11:])
                newline_2 = str(f_contents[g_contents.index(o)][0:11]) + str(f_contents[f_contents.index(i)][11:])
                
                f_contents[f_contents.index(i)] = newline_1
                f_contents[g_contents.index(o)] = newline_2
                
              else:
                pass
            except:
              pass
      with open(x, 'w') as f: 
        f.writelines(f_contents)
        print "changes written"
  except:
    pass
        
##############################################################################
#Converts files from .mol2 to .xyz as required by RMSD library
#saves new .xyz files to child directory of that compound
for file in os.listdir(Path): 
    if file.endswith('.mol2'): 
        check_output(['obabel', '-imol2', file, '-oxyz', '-O' + file[:-5] + '.xyz']) 

for subdirect in subdirects:   
    for file in os.listdir(Path):
        if file.endswith(".xyz"): 
            with open(file, 'r') as f:
                f_contents = f.readlines()
            if str(subdirect) in str(file):  
                with open(Path + '/' + subdirect + '/' + file, 'w') as f: 
                    f.writelines(f_contents)
          
def RMSD(conformer_1, conformer_2): 
    """ RMSD.1.3.2 library taken from https://pypi.org/project/rmsd/ 
        compares to molecules or in this case two conformers to
        produce RMSD value of similarity.

        --conformer_1 base molecule for comparison
        --conformer_2 compared against conformer_1
    """
    return check_output(['calculate_rmsd',  conformer_1 ,  conformer_2]) 

#Takes threshold RMSD value from user
#two identical lists created containing all solutions
#for member of list_1, members of list_2 are compared
#members of list_1 are made keys in a dictionary containing lists
#members of list_2 within the threshold RMSD value for list_1 conformer
#are placed in the list_1 list. 
#that member of list_2 is deleted from list_1 and their key removed 
#from the dictionary
Q = float(raw_input("Type threshold value "))       
for x in subdirects: 
    print "Sorting " + str(x) 
    RMSDPath = str(x)


    list_1 = [] 
    list_2 = [] 
    Ligands_pre_rmsd = [] 
    Ligands = [] 
    for root, dirs, files in os.walk(RMSDPath):
        for file in files: 
            if file.endswith(".xyz"): 
                Ligands_pre_rmsd.append(os.path.join(root, file))  
    for variable in Ligands_pre_rmsd: 
        Ligands.append(variable[int(forward_slashes[-2]) + 1:]) 
    for l in Ligands_pre_rmsd: 
        list_1.append(l)
        list_2.append(l)
 
    #output from rmsd is a string and the number of significant figures given 
    #varies. 
    #have to search for location within the string that the desired values lie.
    conf_lib = {}
    conf_lib_comparison = {}
    with open (RMSDPath + "/RMSD report.txt", 'w') as f:
        for compound_1 in list_1: 
            conf_lib[str(compound_1)] = []
            conf_lib_comparison[str(compound_1)] = []
            for compound_2 in list_2:
                try:
                    if compound_1 == compound_2: 
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                    elif str(RMSD(compound_1, compound_2)[38]) == '.' and float(RMSD(compound_1, compound_2)[37:41]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                    elif str(RMSD(compound_1, compound_2)[39]) == '.' and float(RMSD(compound_1, compound_2)[38:42]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                    elif str(RMSD(compound_1, compound_2)[40]) == '.' and float(RMSD(compound_1, compound_2)[39:43]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                    elif str(RMSD(compound_1, compound_2)[41]) == '.' and float(RMSD(compound_1, compound_2)[40:44]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                    elif str(RMSD(compound_1, compound_2)[42]) == '.' and float(RMSD(compound_1, compound_2)[41:45]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                    elif str(RMSD(compound_1, compound_2)[43]) == '.' and float(RMSD(compound_1, compound_2)[42:46]) <= (Q):
                        conf_lib[str(compound_1)].append(str(compound_2))
                        conf_lib_comparison[str(compound_1)].append(str(compound_2))
                        list_1.remove(compound_2)
                        del conf_lib[str(compound_2)]
                        del conf_lib_comparison[str(compound_2)]
                except:
                        pass
            
   
        #the same solution is often within the threshold value for two conformers
        #the two conformers here compete for the member.
        #improvement here would be to mould these two rounds of competition
        #into one round with a "not" clause. Would massively reduce runtime. 
        for conformer_1 in conf_lib: 
            for conformer_to_be_decided in conf_lib[str(conformer_1)]: 
                for comparison_conformer in conf_lib_comparison:
                    if conformer_1 == comparison_conformer: 
                        pass 
                    elif str(conformer_to_be_decided) in conf_lib_comparison[str(comparison_conformer)] and str(RMSD(conformer_1, conformer_to_be_decided)[13:17]) < str(RMSD(comparison_conformer, conformer_to_be_decided)[13:17]): 
                        conf_lib_comparison[str(comparison_conformer)].remove(str(conformer_to_be_decided))
            
        for conformer_1 in conf_lib_comparison:
            for conformer_to_be_decided in conf_lib_comparison[str(conformer_1)]: 
                for comparison_conformer in conf_lib:
                    if conformer_1 == comparison_conformer: 
                        pass 
                    elif str(conformer_to_be_decided) in conf_lib[str(comparison_conformer)] and str(RMSD(conformer_1, conformer_to_be_decided)[13:17]) < str(RMSD(comparison_conformer, conformer_to_be_decided)[13:17]): 
                        conf_lib[str(comparison_conformer)].remove(str(conformer_to_be_decided))
              
        
        f.write("There are " + str(len(list_1)) + " conformers present." + '\n') 
        f.write('\n')
        for conformer in list_1: 
            f.write("Conformer " + str(int(list_1.index(conformer)) + 1) + ':')
            f.write("  " + str(conformer[int(forward_slashes[-3] - 3):]) + '\n')
            f.write('\n') 
           
           
        for conformer in list_1:
            f.write('\n')
            f.write("    Members of conformer " + str(int(list_1.index(conformer)) + 1) + " include" + '\n')
            f.write('\n')
            for y in conf_lib_comparison[str(conformer)]:       
                f.write("      " + str(y[int(forward_slashes[-3] - 3):]) + '\n')

        plot_list_1 = []
        plot_list_2 = []
        for conformer in list_1: 
            plot_list_1.append(str(conformer[int(forward_slashes[-3] - 3):]))
            plot_list_2.append(len(conf_lib_comparison[str(conformer)]))

        #the same conformer may appear rotated within the protein binding site
        #the different rotations of the same conformer are found here
        pose_members = {} 
        pose_members_comparison = {}
        for conformer_1 in list_1:
            for member in conf_lib_comparison[str(conformer_1)]:
                pose_members[str(member)] = []
                pose_members_comparison[str(member)] = []
            
        for conformer in conf_lib_comparison:
            for member in conf_lib_comparison[str(conformer)]: 
                for comparison_member in conf_lib[str(conformer)]:
                    try:
                        if member == comparison_member: 
                            pose_members[str(member)].append(str(comparison_member))
                        elif str(RMSD(member, comparison_member)[13:17]) <= str(Q):
                            pose_members[str(member)].append(str(comparison_member))
                            pose_members_comparison[str(member)].append(str(comparison_member))
                            conf_lib_comparison[str(conformer)].remove(comparison_member) 
                    except: 
                        pass
           
        #different solution are within the threshold of more than one rotation
        #the two or more rotations compete for the solution   
        for conformer in pose_members: 
            for conformer_to_be_decided in pose_members[str(conformer)]: 
                for comparison_conformer in pose_members_comparison:
                    if conformer == comparison_conformer: 
                        pass 
                    elif str(conformer_to_be_decided) in pose_members_comparison[str(comparison_conformer)] and str(RMSD(conformer_1, conformer_to_be_decided)[13:17]) < str(RMSD(comparison_conformer, conformer_to_be_decided)[13:17]): 
                        pose_members_comparison[str(comparison_conformer)].remove(str(conformer_to_be_decided))
                
        for conformer in pose_members_comparison:
            for conformer_to_be_decided in pose_members_comparison[str(conformer)]: 
                for comparison_conformer in pose_members:
                    if conformer == comparison_conformer: 
                        pass 
                    elif str(conformer_to_be_decided) in pose_members[str(comparison_conformer)] and str(RMSD(conformer, conformer_to_be_decided)[13:17]) < str(RMSD(comparison_conformer, conformer_to_be_decided)[13:17]): 
                        pose_members[str(comparison_conformer)].remove(str(conformer_to_be_decided))
        
    
        for conformer in list_1: 
            f.write('\n')
            f.write("Within conformer " + str(list_1.index(conformer) + 1) + ":" + '\n')
            for y in pose_members: 
                if y in conf_lib_comparison[str(conformer)]: 
                    f.write('\n')
                    f.write(str(len(pose_members[str(y)])) + " are of " + str(y[int(forward_slashes[-2] - 3):]) + '\n') 
       
        plot_x_label = []
        for conformer in list_1:
            plot_x_label.append(str(list_1.index(conformer) + 1))
             
           
        plt.close('all') 
        plt.title(str(x))
        ax = plt.subplot()
        plt.figure(figsize=(6, 8))
        plt.xlabel("Conformers")
  #      ax.set_xticklabels(range(3))
        plt.bar(plot_x_label, plot_list_2, color="#89cff0")
        plt.savefig(RMSDPath + "/" + str(x) + ".png")
                  
print "Done" 